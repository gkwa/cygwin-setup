package PerlIO::scalar;
our $VERSION = '0.01';
use XSLoader ();
XSLoader::load 'PerlIO::scalar';
1;
__END__


